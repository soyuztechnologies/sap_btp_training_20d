using { anubhav.db.master, anubhav.db.transaction } from '../db/datamodel';

service CatalogService @(path:'CatalogService') {

    //suport all CRUD - Create, Read, Update, Delete CRUD
    entity EmployeeSet as projection on master.employees;
    entity ProductSet as projection on master.product;
    entity BusinessPartnerSet as projection on master.businesspartner;
    entity AddressSet as projection on master.address;
    entity POSet as projection on transaction.purchaseorder
    actions{
        //the system will pass the PO primary key - NODE_KEY automatically to input 
        action boost() returns POSet
    };
    entity POItemSet as projection on transaction.poitems;
    //non instance bound because they are not connected to any entity
    function getLargestOrder() returns array of POSet;

};

