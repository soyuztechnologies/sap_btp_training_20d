using { CatalogService as service } from './CatalogService';

annotate  service with @mcp @odata
@mcp.instruction: 'this service allows to show details of business partners (vendors) who has purchase order and items, the items are reffering to products data';
