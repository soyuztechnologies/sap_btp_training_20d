import cds from '@sap/cds'

export default class CatalogService extends cds.ApplicationService { init() {

  const { EmployeeSet, ProductSet, BusinessPartnerSet, AddressSet, POSet, POItemSet } = cds.entities('CatalogService')

  this.before (['CREATE', 'UPDATE'], EmployeeSet, async (req) => {
    console.log('Before CREATE/UPDATE EmployeeSet', req.data)
  })
  this.after ('READ', EmployeeSet, async (employeeSet, req) => {
    console.log('After READ EmployeeSet', employeeSet)
  })
  this.before (['CREATE', 'UPDATE'], ProductSet, async (req) => {
    console.log('Before CREATE/UPDATE ProductSet', req.data)
  })
  this.after ('READ', ProductSet, async (productSet, req) => {
    console.log('After READ ProductSet', productSet)
  })
  this.before (['CREATE', 'UPDATE'], BusinessPartnerSet, async (req) => {
    console.log('Before CREATE/UPDATE BusinessPartnerSet', req.data)
  })
  this.after ('READ', BusinessPartnerSet, async (businessPartnerSet, req) => {
    console.log('After READ BusinessPartnerSet', businessPartnerSet)
  })
  this.before (['CREATE', 'UPDATE'], AddressSet, async (req) => {
    console.log('Before CREATE/UPDATE AddressSet', req.data)
  })
  this.after ('READ', AddressSet, async (addressSet, req) => {
    console.log('After READ AddressSet', addressSet)
  })
  this.before (['CREATE', 'UPDATE'], POSet, async (req) => {
    console.log('Before CREATE/UPDATE POSet', req.data)
  })
  this.after ('READ', POSet, async (pOSet, req) => {
    console.log('After READ POSet', pOSet)
  })
  this.before (['CREATE', 'UPDATE'], POItemSet, async (req) => {
    console.log('Before CREATE/UPDATE POItemSet', req.data)
  })
  this.after ('READ', POItemSet, async (pOItemSet, req) => {
    console.log('After READ POItemSet', pOItemSet)
  })

  this.on ('getLargestOrder', async (req) => {
    console.log('On getLargestOrder', req.data)
  })

    //generic handler to support my function implementation - always returns data, GET
  this.on('getLargestOrder', async (req,res) => {
    try {

      const tx = cds.tx(req);

      //use CDS QL to make call to DB  - SELECT * UP TO 3 ROWS FROM POs ORDER BY GROSS_AMOUNT descending
      const reply = await tx.read(POSet).orderBy({
        'GROSS_AMOUNT': 'desc'
      }).limit(3);

      return reply;

    } catch (error) {
      req.error(500, "Some error occurred : " + error.toString())
    }
  });

  //implementation of action - Create, Update data in server
  this.on('boost', async(req) => {
    //    debugger;
    try {
      
      //extract the primary key JSON - {NODE_KEY: 'key value'}
      const PRIMARYKEY = req.params[0];
      //start a transaction to db
      const tx = cds.tx(req);
      //CDS Query language to update your gross_amount by +20000
      await tx.update(POSet).with({
        GROSS_AMOUNT  : { '+=' : 20000 },
        NOTE: 'Boosted!!'
      }).where(PRIMARYKEY);
      //read the record and send in out
      return await tx.read(POSet).where(PRIMARYKEY);


    } catch (error) {
      
    }

  });

  return super.init()
}}
