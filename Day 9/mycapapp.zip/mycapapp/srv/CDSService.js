import cds from '@sap/cds'

// Must be the DEFAULT export: the service is namespaced (new.service.CDSService),
// so a named export "CDSService" is not matched and the handlers are silently ignored.
export default class CDSService extends cds.ApplicationService { init() {

  const { ProductViewSet, ItemView } = cds.entities('new.service.CDSService')

  this.before (['CREATE', 'UPDATE'], ProductViewSet, async (req) => {
    console.log('Before CREATE/UPDATE ProductViewSet', req.data)
  })
  // Virtual elements are never read from the DB - they must be filled here,
  // otherwise OData omits them from the response.
  this.after ('READ', ProductViewSet, async (productViewSet, req) => {
    console.log('>>> DEBUG after READ fired, rows:', productViewSet?.length)
        // for (let index = 0; index < productViewSet.length; index++) {
    //   const element = productViewSet[index];
    //   element.soldCount = 10;
    // }
    // console.log(productViewSet)
  })
  this.before (['CREATE', 'UPDATE'], ItemView, async (req) => {
    console.log('Before CREATE/UPDATE ItemView', req.data)
  })
  this.after ('READ', ItemView, async (itemView, req) => {
    console.log('After READ ItemView', itemView)
  })


  return super.init()
}}
