import cds from '@sap/cds'

export class MyService extends cds.ApplicationService { init() {

  this.on ('hello', async (req) => {
    return "Hello " + req.data.spiderman;
  })

  return super.init()
}}
