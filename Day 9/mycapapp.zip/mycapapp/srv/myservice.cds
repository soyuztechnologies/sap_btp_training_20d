service MyService {

    function hello(spiderman: String) returns String;

}