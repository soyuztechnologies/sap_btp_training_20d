using { cappo.cds } from '../db/CDSViews';

namespace new.service;

service CDSService @(path:'CDSService'){

    entity ProductViewSet as projection on cds.CDSViews.ProductView{
        *,
        virtual soldCount: Int16
    };
    entity ItemView as projection on cds.CDSViews.ItemView;

}